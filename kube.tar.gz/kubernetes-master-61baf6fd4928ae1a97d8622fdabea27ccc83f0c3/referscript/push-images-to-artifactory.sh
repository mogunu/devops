#!/bin/bash

# SET VARIABLE TO STORE THE DOCKER IMAGE SERVER
DOCKER_IMAGE_SERVER=api.aigdevopscoe.net:30003

# START DOCKER SERVICE
service docker start

# CHECK DOCKER VERSION
docker version

# UPDATE THE daemon.json FILE TO CONTAIN THE DOCKER IMAGE SERVER
echo '{ "insecure-registries":["'$DOCKER_IMAGE_SERVER'"] }' > /etc/docker/daemon.json

# RESTART DOCKER SERVICE
service docker restart

# LOG INTO THE DOCKER IMAGE SERVER
docker login $DOCKER_IMAGE_SERVER  -p password -u admin

# CHECK WHETHER CHANGE IS REFLECTED
cat ~/.docker/config.json

# GO TO 'dockerfiles' DIRECTORY
cd /opt/kubernetes/dockerfiles/

# BUILD THE IMAGES
docker build -t api.aigdevopscoe.net:30003/docker/jenkins:latest -f Jenkins_dockerfile .
docker build -t api.aigdevopscoe.net:30003/docker/slave:latest -f Slave_dockerfile .
docker build -t api.aigdevopscoe.net:30003/docker/maven:latest -f Maven_dockerfile .

# TAG THE IMAGES
#docker tag jenkins api.aigdevopscoe.net:30003/docker/jenkins:latest
#docker tag jenkins-slave api.aigdevopscoe.net:30003/docker/jenkins-slave:latest

# PUSH THE IMAGES TO ARTIFACTORY
docker push api.aigdevopscoe.net:30003/docker/jenkins:latest
docker push api.aigdevopscoe.net:30003/docker/slave:latest
docker push api.aigdevopscoe.net:30003/docker/maven:latest
