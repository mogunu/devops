kubectl delete deployment custmgmtapp -n devops
kubectl delete svc custmgmtapp-svc -n devops
