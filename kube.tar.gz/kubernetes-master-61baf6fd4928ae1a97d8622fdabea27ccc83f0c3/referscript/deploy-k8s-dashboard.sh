#!/bin/bash

kubectl create -f https://raw.githubusercontent.com/kubernetes/dashboard/master/src/deploy/recommended/kubernetes-dashboard.yaml

echo 'USERNAME --> admin'

echo 'DASHBOARD CREDENTIALS: '$(kops get secrets kube --type secret -o plaintext)

echo 'DASHBOARD TOKEN: '$(kops get secrets admin --type secret -o plaintext)

echo 'ACCESS DASHBOARD --> https://'$(kubectl get nodes -owide | awk '/master/{print $6}')'/api/v1/namespaces/kube-system/services/https:kubernetes-dashboard:/proxy/' 
