# SET ARTIFACTORY YAMLS PATH
ARTIFACTORY='/opt/kubernetes/yamlfiles/artifactory'

# DEPLOY postgresql
kubectl apply -f $ARTIFACTORY/postgresql-storage.yml -n devops
kubectl apply -f $ARTIFACTORY/postgresql.yml -n devops

# DEPLOY artifactory
kubectl apply -f $ARTIFACTORY/artifactory-storage.yml -n devops
kubectl apply -f $ARTIFACTORY/artifactory-deployment.yml  -n devops
kubectl apply -f $ARTIFACTORY/artifactory-service.yml -n devops

echo "ARTIFACTORY POD DETAILS"
kubectl get pods -n devops

echo "ARTIFACTORY DEPLOYMENTS DETAILS"
kubectl get deployments -n devops

echo "ARTIFACTORY SERVICE DETAILS"
kubectl get services -n devops
