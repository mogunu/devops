kubectl delete service artifactory -n devops
kubectl delete deployment artifactory-k8s-deployment -n devops
kubectl delete persistentvolumeclaim artifactory-claim -n devops

kubectl delete service postgresql-k8s-service -n devops
kubectl delete deployment postgresql-k8s-deployment -n devops
kubectl delete persistentvolumeclaim postgresql-claim -n devops

