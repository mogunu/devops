#!/bin/bash

# SET PATH
#export PATH=$PATH:/usr/local/bin

# CHECK IF HELM IS INSTALLED OR NOT
#if ! helm version --client &> /dev/null
#then
#	echo "INSTALLING HELM"
#	curl https://raw.githubusercontent.com/kubernetes/helm/master/scripts/get > /tmp/get_helm.sh
#	chmod 700 /tmp/get_helm.sh
#	DESIRED_VERSION=v2.8.2 /tmp/get_helm.sh
#fi

# This will install Tiller to your running Kubernetes cluster.
# It will also set up any necessary local configuration.
#helm init --wait

# CREATE CLUSTERROLEBINDING
#kubectl --namespace=kube-system create clusterrolebinding add-on-cluster-admin-helm --clusterrole=cluster-admin --serviceaccount=kube-system:default

# CONFIGURE HELP VARIABLES
#helm ls

# GO TO HOME DIRECTORY
cd ~/

# GIT CLONE THE PROJECTS
if ! ls -al ~ | grep charts
then
	git clone https://github.com/kubernetes/charts
fi

# SET YAML FILES PATH
YAMLPATH='/opt/kubernetes/yamlfiles/grafana-prometheus'

# CREATE NAMESPACE 'monitoring'
kubectl create ns monitoring

# INSTALL PROMETHEUS
helm install -f $YAMLPATH/prometheus-values.yml charts/stable/prometheus --name prometheus --namespace monitoring

# INSTALL GRAFANA
helm install -f $YAMLPATH/grafana-values.yml charts/stable/grafana/ --name grafana --namespace monitoring

# INSTALL SERVICE FOR GRAFANA
kubectl apply -f $YAMLPATH/grafana-ext.yml

# INSTALL SERVICE FOR PROMETHEUS
kubectl apply -f $YAMLPATH/prometheus-ext.yaml

# GET STATUS OF THE PODS
kubectl get pods -n monitoring
kubectl get pods -n monitoring

# ACCESS GRAFANA AND PROMETHEUS
echo 'GRAFANA --> http://'$(kubectl get nodes -owide | awk '/master/{print $6}')':30020'
echo 'PROMETHEUS --> http://'$(kubectl get nodes -owide | awk '/master/{print $6}')':31009'
echo 'FOR CONFIGURING DATASOURCE IN GRAFANA USE http://prometheus-server.monitoring.svc.cluster.local'
