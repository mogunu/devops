#!/bin/bash

# VAULT CONFIGURATION
Vault_Pod=$(kubectl get pods --namespace devops -l "app=vault" -o jsonpath="{.items[0].metadata.name}")
VAULT_TOKEN=$(kubectl logs $Vault_Pod -n devops | grep 'Root Token' | cut -d' ' -f3)
Master_IP=$(kubectl get nodes -owide | awk '/master/{print $6}')

# INSTALL JQ
yum update
yum install -y jq

# ARTIFACTORY USERNAME AND PASSWORD
PASSWORD=$(curl -s -X GET -H "X-Vault-Token:$VAULT_TOKEN" http://$Master_IP:30030/v1/cred/artifactory | jq -r '.data.password')
USERNAME=$(curl -s -X GET -H "X-Vault-Token:$VAULT_TOKEN" http://$Master_IP:30030/v1/cred/artifactory | jq -r '.data.username')

echo $USERNAME
echo $PASSWORD

# LOOP THROUGH THE NODES OF THE CLUSTER TO CONFIGURE THEM TO PULL IMAGES FROM ARTIFACTORY
for ip in $(kubectl get nodes -owide | awk '/node/{print $6}')
do
    ssh -i $(aws ec2 describe-key-pairs --query 'KeyPairs[?starts_with(KeyName, `kubernetes.aigdevopscoe.net-`) == `true`]' | awk '{print $2}').pem -o "StrictHostKeyChecking no" admin@$ip < /opt/kubernetes/referscript/loginto-artifactory.sh
done
