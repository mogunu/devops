#!/bin/bash
echo 'WHICH CLUSTER DO YOU WANT TO DELETE?'
echo 'CLUSTERS'

kops get clusters | cut -f 1 | sed '1d'

while ! kops get clusters | cut -f 1 | sed '1d' | grep -q $CLUSTER_NAME &> /dev/null
do
  echo -n "ENTER THE NAME OF THE CLUSTER YOU WANT TO DELETE: "
  read CLUSTER_NAME
done

kops delete cluster --name=$CLUSTER_NAME --yes

