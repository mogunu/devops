# SET JENKINS-YAML-PATH VARIABLE
JENKINS=/opt/kubernetes/yamlfiles/jenkins

# CREATE 'jenkins-agents' AND 'jenkins-masters' NAMESPACES
kubectl create -f $JENKINS/jenkins-masters-ns.yaml
kubectl create -f $JENKINS/jenkins-agents-ns.yaml

# CONFIGURE JENKINS PLUGIN
kubectl create -f $JENKINS/jenkins-k8s-plugin-conf.yaml
kubectl create clusterrolebinding add-on-cluster-admin --clusterrole=cluster-admin --serviceaccount=jenkins-masters:jenkins --namespace=jenkins-masters

# DEPLOY JENKINS
kubectl create -f $JENKINS/jenkins-sts.yaml
kubectl create -f $JENKINS/jenkins-svc.yaml
