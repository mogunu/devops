single="ls -l"
$single
