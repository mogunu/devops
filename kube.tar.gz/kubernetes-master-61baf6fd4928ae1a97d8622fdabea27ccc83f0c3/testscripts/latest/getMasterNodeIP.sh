kubectl get nodes -owide | awk '/master/{print $6}'
