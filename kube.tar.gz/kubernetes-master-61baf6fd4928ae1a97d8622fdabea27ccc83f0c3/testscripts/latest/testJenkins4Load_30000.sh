#!/bin/bash
# -------------------- SHELL SCRIPT GENERIC --------------------
echo "Please enter the total number of jobs to create:"
read n

echo "This script would do the below activities:"
echo " 1. Clone an existing job into a series of new ones"
echo " 2. Run all the jobs in parallel"
echo " 3. Delete the newly created jobs"

echo "1)"
# Parameters for using to do the testing of the Jenkins job
user="admin"
password="admin"
Jenkin_Mac=$(kubectl get nodes -owide | awk '/master/{print $6}')
#Port=8080
Port=31000

existing_job=Test


echo 'Get the CRUMB from Jenkins website for authentication:'
echo '## Note: If it gets stuck at the below line, then check the name of the Jenkins master provided above and correct if needed.'
echo "wget -q --auth-no-challenge --user $user --password $password --output-document - 'http://$Jenkin_Mac:$Port/crumbIssuer/api/xml?xpath=concat(//crumbRequestField,"\"":"\"",//crumb)'" > a.txt

#CRUMB1=$(wget -q --auth-no-challenge --user $user --password $password --output-document - 'http://$Jenkin_Mac:$Port/crumbIssuer/api/xml?xpath=concat(//crumbRequestField,":",//crumb)')
#echo "CRUMB1 = $CRUMB1"

#echo "CATTING A.TXT"
#cat a.txt

sudo bash ./a.txt > tmp
#echo "CATTING TMP"
#cat tmp
CRUMB=$(cat tmp)

echo "Got CRUMB to be: '$CRUMB'"

if [ "$CRUMB" == "" ]
then
      echo "Please update the CSRF (Cross Site Request Forgery) under Manage Jenkins -> Configure Global Security "
      exit 1
else
      echo "The crumb got is: $CRUMB"
fi

echo "The existing job which is being cloned is: '$existing_job'"
echo "curl -s -XGET 'http://$Jenkin_Mac:$Port/checkJobName?value=$existing_job' -u admin:admin -H "\""$CRUMB"\"" | grep 'A job already exists' | wc -c" > a.txt
echo "CATTING a.txt FOR EXISTINGJOB_COUNT"
cat a.txt
sudo bash ./a.txt > tmp
EXISTINGJOB_COUNT=$(cat tmp)
echo "EXISTINGJOB_COUNT = $EXISTINGJOB_COUNT"

if [ $EXISTINGJOB_COUNT -gt 0 ]
then
	echo "Take out the config.xml from an existing job:"
	echo "curl -X GET http://$Jenkin_Mac:$Port/job/$existing_job/config.xml -u $user:$password -o testjob_config.xml"
	curl -s -X GET http://$Jenkin_Mac:$Port/job/$existing_job/config.xml -u $user:$password -o testjob_config.xml
else
	echo "The job with the name provided here for 'existing_job' does not exist. Please create it and then run this script."
	exit
fi


echo ""
echo "2)"
echo "Create new jobs from the above taken config.xml:"

cat Seed_pipeline_config_header.xml > seed_pipeline_config.xml
i=1
# For that create the 'script' tag and then replace this data inside that from the template
echo "pipeline" >> seed_pipeline_config.xml
echo "{" >> seed_pipeline_config.xml
echo "    agent none" >> seed_pipeline_config.xml
echo "    stages " >> seed_pipeline_config.xml
echo "	{" >> seed_pipeline_config.xml
echo "        stage('Run Tests') " >> seed_pipeline_config.xml
echo "		{" >> seed_pipeline_config.xml
echo "            parallel " >> seed_pipeline_config.xml
echo "			{" >> seed_pipeline_config.xml

# Loop through for the number of jobs to be created, configure the name and also write to the seed_pipeline_config.xml to write into the script tag
while (( $i <= $n  ))
do
    new_job="$existing_job-$i"
    echo "A new job will be created with name: '$new_job'"
	echo "curl -s -XGET 'http://$Jenkin_Mac:$Port/checkJobName?value=$new_job' -u admin:admin -H "\""$CRUMB"\"" | grep 'A job already exists' | wc -c" > a.txt
	echo "CATTING a.txt FOR TESTJOB_COUNT"
	cat a.txt
	sudo bash ./a.txt > tmp
	TESTJOB_COUNT=$(cat tmp)
	echo "TESTJOB_COUNT = $TESTJOB_COUNT"

	if [ $TESTJOB_COUNT -gt 0 ]
	then
		echo "Job already exists and not creating"
	else
		echo "Job does not exist and so creating it"
		STR_COPY_JOB="curl -s -XPOST 'http://$Jenkin_Mac:$Port/createItem?name=$new_job' --data-binary @testjob_config.xml -u $user:$password -H "\""$CRUMB"\""  -H "\""Content-Type:text/xml"\"""
		echo $STR_COPY_JOB > b.txt
		sudo bash ./b.txt
	fi
echo "                stage('$new_job')" >> seed_pipeline_config.xml
echo "				{" >> seed_pipeline_config.xml
echo "                    agent any" >> seed_pipeline_config.xml
echo "                    steps " >> seed_pipeline_config.xml
echo "					{" >> seed_pipeline_config.xml
echo "                        echo 'ASDF'" >> seed_pipeline_config.xml
echo "                        build job: '$new_job'" >> seed_pipeline_config.xml
echo "                    }" >> seed_pipeline_config.xml
echo "                }" >> seed_pipeline_config.xml

    i=$(( i+1 ))
done

# Once finished the looping to create jobs and writing into seed_pipeline_config.xml for script tag, now close all the open braces
echo "			}" >> seed_pipeline_config.xml
echo "        }" >> seed_pipeline_config.xml
echo "    }" >> seed_pipeline_config.xml
echo "}" >> seed_pipeline_config.xml

cat Seed_pipeline_config_footer.xml >> seed_pipeline_config.xml

echo ""
echo "Now that all jobs have been created as needed, run them all in parallel using SEED_PIPELINE job"
#i=1
#while (( $i <= $n  ))
#do
#    new_job="$existing_job-$i"
#    echo "A new job will be created with name: '$new_job'"
#	curl -I -X POST http://$Jenkin_Mac:$Port/job/$new_job/build -H "$CRUMB" -u $user:$password
#    i=$(( i+1 ))
#done
echo "Check if the seed_pipeline job exists"
#SEEDJOB_COUNT=$(curl -s -XGET 'http://54.202.37.194:8080/checkJobName?value=seed_pipeline' -u admin:admin -H "Jenkins-Crumb:e6c51c0b454b7c2f3de641f73dee781a" | grep 'A job already exists' | wc -c)
SEEDJOB_COUNT=$(curl -s -XGET '$Jenkin_Mac:$Port/checkJobName?value=seed_pipeline' -u admin:admin -H "$CRUMB" | grep 'A job already exists' | wc -c)

if [ $SEEDJOB_COUNT -gt 0 ]
then
        echo "Update the config.xml of seed_pipeline job (delete & create the job):"
        curl -s -XPOST 'http://$Jenkin_Mac:$Port/job/seed_pipeline/doDelete' -u $admin:$password -H "$CRUMB"

#       curl -s -XPOST 'http://$Jenkin_Mac:$Port/job/seed_pipeline/config.xml' --data-binary @seed_pipeline_config.xml -u $admin:$password -H "$CRUMB"  -H "Content-Type:text/xml"
        #curl -s -XPOST 'http://$Jenkin_Mac:$Port/job/seed_pipeline/config.xml' --data-binary @seed_pipeline_config.xml -u $admin:$password -H "$CRUMB"  -H "Content-Type:text/xml"
        #SEEDJOB_UPDATE="curl -s -XPOST 'http://$Jenkin_Mac:$Port/job/seed_pipeline/config.xml' --data-binary @seed_pipeline_config.xml -u $user:$password -H "\""$CRUMB"\""  -H "\""Content-Type:text/xml"\"""
        SEEDJOB_UPDATE="curl -s -XPOST 'http://$Jenkin_Mac:$Port/createItem?name=seed_pipeline' --data-binary @seed_pipeline_config.xml -u $user:$password -H "\""$CRUMB"\""  -H "\""Content-Type:text/xml"\"""

        echo $SEEDJOB_UPDATE > SEEDJOB_UPDATE.txt
        echo "CATTING SEEDJOB_UPDATE.txt"
        cat SEEDJOB_UPDATE.txt
        sudo bash ./SEEDJOB_UPDATE.txt
else
        echo "Does not exist - create new seed_pipeline job from the updated config.xml"
        #curl -X GET http://$Jenkin_Mac:$Port/ig.xml -u $user:$password -o seed_pipeline_config.xml
        SEEDJOB_UPDATE="curl -s -XPOST 'http://$Jenkin_Mac:$Port/createItem?name=seed_pipeline' --data-binary @seed_pipeline_config.xml -u $user:$password -H "\""$CRUMB"\""  -H "\""Content-Type:text/xml"\"""
        echo $SEEDJOB_UPDATE > SEEDJOB_UPDATE.txt
        echo "CATTING SEEDJOB_UPDATE.txt"
        cat SEEDJOB_UPDATE.txt
        sudo bash ./SEEDJOB_UPDATE.txt
fi

echo "Now run the seed_pipeline job to execute all the jobs in parallel that were created above"
curl -I -X POST http://$Jenkin_Mac:$Port/job/seed_pipeline/build -H "$CRUMB" -u $user:$password


echo ""
echo "3)"
echo "Delete all jobs once all of them have run:"
echo "Do you want to delete all job [y/n]?"
read yn
if [ "$yn" == "y" ]
then
	i=1
	while (( $i <= $n  ))
	do
		new_job="$existing_job-$i"
		echo "The job with this name will be deleted: '$new_job'"
#		curl -s -XPOST 'http://$Jenkin_Mac:$Port/job/$new_job/doDelete' --user $admin --password $password -H "$CRUMB"
		curl -s -XPOST 'http://$Jenkin_Mac:$Port/job/$new_job/doDelete' -u $admin:$password -H "$CRUMB"
		i=$(( i+1 ))
	done
else
	echo "Not deleting any job"
fi

