#!/bin/bash
n=1
while (( $n <= 5 ))
do
	echo "Welcome $n times."
	n=$(( n+1 ))	
done

read x
i=0
#while (( $i < 5 ))
while (( $i < $x ))
do
    echo "Hi $i"
    i=$(( $i+1  ))
done
