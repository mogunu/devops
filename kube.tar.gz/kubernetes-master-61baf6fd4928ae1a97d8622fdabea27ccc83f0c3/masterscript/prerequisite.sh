#!/bin/bash

# SET PATH
export PATH=$PATH:/usr/local/bin

# CHECK IF HELM IS INSTALLED OR NOT
if ! helm version --client &> /dev/null
then
        echo "INSTALLING HELM"
        curl https://raw.githubusercontent.com/kubernetes/helm/master/scripts/get > /tmp/get_helm.sh
        chmod 700 /tmp/get_helm.sh
        DESIRED_VERSION=v2.8.2 /tmp/get_helm.sh
fi

# This will install Tiller to your running Kubernetes cluster.
# It will also set up any necessary local configuration.
helm init --wait

# CREATE CLUSTERROLEBINDING
kubectl --namespace=kube-system create clusterrolebinding add-on-cluster-admin-helm --clusterrole=cluster-admin --serviceaccount=kube-system:default

# CONFIGURE HELP VARIABLES
helm ls

# CREATE NAMESPACE 'devops'
kubectl create ns devops

# SET package FOLDER DIRECTORY
PKG=/opt/kubernetes/package

# DEPLOY ARTIFACTORY
#/opt/kubernetes/referscript/deploy-artifactory.sh
helm install $PKG/artifactory -f $PKG/artifactory/artifactory-values.yaml --name artifactory --namespace devops

# DEPLOY VAULT
#kubectl create -f /opt/kubernetes/yamlfiles/vault/vault.yaml
helm install $PKG/vault -f $PKG/vault/vault-values.yaml --name vault --namespace devops
