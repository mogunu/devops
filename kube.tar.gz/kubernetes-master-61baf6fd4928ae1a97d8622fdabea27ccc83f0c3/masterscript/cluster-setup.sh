#!/bin/bash

# Check whether the PATH variable is set or not
if ! echo $PATH | grep -q /usr/local/bin
then
        echo "SETTING UP THE PATH VARIABLE"
        export PATH=$PATH:/usr/local/bin
fi

# Check If Kubectl is already installed or not
if kubectl version --client=true &> /dev/null
then
        echo "KUBECTL IS ALREADY INSTALLED"
        kubectl version --client=true
else
        curl -LO https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)/bin/linux/amd64/kubectl
        chmod +x ./kubectl
        mv ./kubectl /usr/bin/kubectl
        if ! kubectl version --client=true &> /dev/null
        then
                echo "THERE WAS A PROBLEM INSTALLING KUBECTL. TERMINATING"
                exit 1
        fi
        kubectl version --client=true
fi

# Check If Kops is already installed or not
if kops version | grep -q -i version &> /dev/null
then
        echo "KOPS IS ALREADY INSTALLED"
        kops version
else
        # Otherwise install Kops
        curl -LO https://github.com/kubernetes/kops/releases/download/1.10.0/kops-linux-amd64
        chmod +x kops-linux-amd64
        mv kops-linux-amd64 /usr/bin/kops
        if ! kops version &> /dev/null
        then
                echo "THERE WAS A PROBLEM INSTALLING KOPS. TERMINATING"
                exit 1
        fi
        kops version
fi

# Check if AWS CLI is installed or not
if aws --version &> /dev/null
then
        echo "AWS CLI IS ALREADY INSTALLED"
        aws --version
else
        if ! pip --version | grep -q -i pip &> /dev/null
        then
                echo "INSTALLING PIP"
                curl https://bootstrap.pypa.io/get-pip.py -o ~/get-pip.py
                python ~/get-pip.py
                if ! pip --version &> /dev/null
                then
                        echo "THERE WAS A PROBLEM INSTALLING PIP. TERMINATING"
                        exit 1
                fi
                pip --version
        fi
        pip install awscli
        if ! aws --version &> /dev/null
        then
                echo "THERE WAS A PROBLEM INSTALLING AWS-CLI. TERMINATING"
                exit 1
        fi
        aws --version
fi

# Configure AWS
aws configure

# TAKE DOMAIN NAME INPUT
read -p "PLEASE ENTER A VALID DOMAIN NAME: " DOMAIN_NAME
while [[ $DOMAIN_NAME != *'.'* ]] || [[ $DOMAIN_NAME == '' ]]
do
    echo "INVALID DOMAIN NAME"
    read -p "PLEASE ENTER A VALID DOMAIN NAME: " DOMAIN_NAME
done
#echo "DOMAIN NAME IS: "$DOMAIN_NAME

# Check if bucket 'clusters.aigdevopscoe.net' already exists or not
#if ! aws s3 ls | grep -i 'clusters.'$DOMAIN_NAME > /dev/null	
#then
#        echo 'CREATING NEW BUCKET'
#        aws s3 mb s3://clusters.$DOMAIN_NAME
#fi

# Check if bucket 'clusters.aigdevopscoe.net' already exists or not
if aws s3 ls | grep -i 'clusters.'$DOMAIN_NAME > /dev/null
then
        echo 'REMOVING THE OLD BUCKET'
        # Remove old bucket
        aws s3 rb s3://clusters.$DOMAIN_NAME --force
fi
echo 'CREATING NEW BUCKET'
aws s3 mb s3://clusters.$DOMAIN_NAME

# Set KOPS_STATE_STORE environment variable
sed  -i '/KOPS_STATE_STORE/d' ~/.bash_profile
echo 'export KOPS_STATE_STORE=s3://clusters.'$DOMAIN_NAME >> ~/.bash_profile

# Refresh .bashrc file
source ~/.bash_profile

# Take inputs from user to create cluster configuration
while ! [[ "$MASTER_TYPE" =~ ^(t2.small|t2.medium|t2.large|t2.xlarge)$ ]]
do
  echo -n "WHICH MACHINE TYPE DO YOU WANT TO USE FOR MASTER: t2.small|t2.medium|t2.large|t2.xlarge? "
  read -r MASTER_TYPE
done

while ! [[ "$NODE_TYPE" =~ ^(t2.small|t2.medium|t2.large|t2.xlarge)$ ]]
do
  echo -n "WHICH MACHINE TYPE DO YOU WANT TO USE FOR NODE: t2.small|t2.medium|t2.large|t2.xlarge? "
  read -r NODE_TYPE
done

RE='^[0-9]+$'
while ! [[ $NODE_NO =~ $RE ]]
do
  echo -n "HOW MANY NODES DO YOU WANT? : "
  read -r NODE_NO
done

# Build your cluster configuration
kops create cluster \
    --cloud aws \
    --node-count $NODE_NO \
    --node-size $NODE_TYPE \
    --master-size $MASTER_TYPE \
    --zones $(aws ec2 describe-availability-zones --query "AvailabilityZones[?State=='available'].{Name:ZoneName}" | head --lines 1) \
    --name $DOMAIN_NAME > /dev/null

# Create public and private keys for SSH
if ls -al ~/.ssh/ | grep -q id_rsa
then
        echo 'SSH KEYS ALREADY PRESENT'
else
        ssh-keygen -t rsa -N "" -f ~/.ssh/id_rsa
fi

# Create secret using public key
kops create secret --name $DOMAIN_NAME sshpublickey admin -i ~/.ssh/id_rsa.pub

# Create the cluster in AWS
kops update cluster $DOMAIN_NAME --yes

# Wait while the cluster is getting started
if !(kops validate cluster &> /dev/null)
then
        echo -n "CLUSTER IS NOT READY YET. PLEASE WAIT"
fi
while !(kops validate cluster &> /dev/null)
do
        echo -n "."
        sleep 10
done
kops validate cluster

# Update cluster with PodNodeSelector
kops get cluster --full -o=yaml > /opt/kubernetes/yamlfiles/kops-cluster-data.yaml
sed -i '/PodNodeSelector/d' /opt/kubernetes/yamlfiles/kops-cluster-data.yaml
sed -i '/^$/d' /opt/kubernetes/yamlfiles/kops-cluster-data.yaml
sed -i '/^[//]/ d' /opt/kubernetes/yamlfiles/kops-cluster-data.yaml
sed -i '/enableAdmissionPlugins:/a\    - PodNodeSelector' /opt/kubernetes/yamlfiles/kops-cluster-data.yaml
kops replace -f /opt/kubernetes/yamlfiles/kops-cluster-data.yaml

# Create instancegroups
kops create -f /opt/kubernetes/yamlfiles/jenkins/jenkins-agents-ig.yaml &> /dev/null
kops create -f /opt/kubernetes/yamlfiles/jenkins/jenkins-masters-ig.yaml &> /dev/null

# Update the cluster for the changes to be reflected
kops update cluster --yes
kops rolling-update cluster --yes

# Configure Nodes
/opt/kubernetes/referscript/node-config-cli.sh $DOMAIN_NAME
