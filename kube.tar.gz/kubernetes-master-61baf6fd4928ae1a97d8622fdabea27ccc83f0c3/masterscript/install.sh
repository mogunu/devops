#!/bin/bash

# SET PACKAGE PATH VARIABLE
PKG=/opt/kubernetes/package

# CREATE POLICY AND ADD SECRETS
/opt/kubernetes/referscript/create-policy.sh 

# CONFIGURE NODES TO USE ARTIFACTORY
/opt/kubernetes/referscript/node-config-artifactory.sh

# PUSH IMAGES TO ARTIFACTORY
/opt/kubernetes/referscript/push-images-to-artifactory.sh

# DEPLOY SPRING CLOUD
/opt/kubernetes/referscript/build-push-spring-cloud-config-server-image.sh
#kubectl create -f /opt/kubernetes/yamlfiles/spring-cloud-config-server/spring-cloud-config-server-deployment.yaml -n devops
#kubectl create -f /opt/kubernetes/yamlfiles/spring-cloud-config-server/spring-cloud-config-server-pvc.yaml -n devops
#kubectl create -f /opt/kubernetes/yamlfiles/spring-cloud-config-server/spring-cloud-config-server-svc.yaml -n devops
helm install $PKG/spring-cloud-config-server -f $PKG/spring-cloud-config-server/values.yaml --name spring-cloud --namespace=devops

# DEPLOY THE CLUSTER AUTOSCALER
kubectl create -f /opt/kubernetes/yamlfiles/cluster-autoscaler.yaml

# SET JENKINS-YAML-PATH VARIABLE
JENKINS=/opt/kubernetes/yamlfiles/jenkins

# CREATE 'jenkins-agents' AND 'jenkins-masters' NAMESPACES
kubectl create -f $JENKINS/jenkins-masters-ns.yaml
kubectl create -f $JENKINS/jenkins-agents-ns.yaml

# CONFIGURE JENKINS PLUGIN
kubectl create -f $JENKINS/jenkins-k8s-plugin-conf.yaml
kubectl create clusterrolebinding add-on-cluster-admin --clusterrole=cluster-admin --serviceaccount=jenkins-masters:jenkins --namespace=jenkins-masters

# DEPLOY JENKINS
#/opt/kubernetes/referscript/deploy-jenkins.sh
helm install $PKG/jenkins -f $PKG/jenkins/jenkins-values.yaml --name jenkins --namespace jenkins-masters

# DEPLOY SONARQUBE
#/opt/kubernetes/referscript/deploy-sonarqube.sh
helm install $PKG/sonarqube -f $PKG/sonarqube/sonarqube-values.yaml --name sonarqube --namespace devops

# DEPLOY PROMETHEUS AND GRAFANA
/opt/kubernetes/referscript/deploy-prometheus-grafana.sh

# INSTALL K8S DASHBOARD
/opt/kubernetes/referscript/deploy-k8s-dashboard.sh
